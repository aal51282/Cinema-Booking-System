-- SQLite
UPDATE Users Set isAdmin = 1 WHERE userId = 9;
SELECT * FROM Users WHERE userId = 9;

