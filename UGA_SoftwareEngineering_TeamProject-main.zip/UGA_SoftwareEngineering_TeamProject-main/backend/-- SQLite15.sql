-- SQLite
DELETE FROM Movies WHERE id = 10;