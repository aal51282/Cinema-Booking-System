export interface Show{
    showId?: number; 
    movieId: number; 
    roomId: number;
    showDate: number;   
    endTime: number;
}