export interface ShowRoom {
    roomId: number; 
    roomName: string;
    capacity: number;
}